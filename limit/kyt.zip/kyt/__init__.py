from telethon import *
import datetime as DT
from telethon import Button
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging

# Init
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# Load config dari var.txt
exec(open("kyt/var.txt", "r").read())

# Start bot
bot = TelegramClient("ddsdswl", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# Init database admin
try:
    open("kyt/database.db")
except:
    x = sqlite3.connect("kyt/database.db")
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)", (ADMIN,))
    x.commit()

# Function akses DB
def get_db():
    x = sqlite3.connect("kyt/database.db")
    x.row_factory = sqlite3.Row
    return x

# Validasi admin
def valid(id):
    db = get_db()
    x = db.execute("SELECT user_id FROM admin").fetchall()
    a = [v[0] for v in x]
    return "true" if id in a else "false"

# Konversi ukuran file
def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])

@bot.on(events.NewMessage(pattern="/start"))
async def start_cmd(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) == "false":
        await event.respond("🚫 Akses Ditolak, lu bukan mets 😎")
        return

    # Kirim gambar banner dari file lokal
    file_path = "/root/Assets/kemetbot.jpg"  # ✅ Ganti sesuai lokasi file banner
    if os.path.exists(file_path):
        await bot.send_file(event.chat_id, file_path)

    # Teks keren sebagai banner text
    start_text = f"""```
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝗞𝗘𝗠𝗘𝗧 𝗝𝗦 𝗦𝗧𝗢𝗥𝗘 𝗩𝗣𝗡 𝗕𝗢𝗧 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
📆 Aktif Sejak: {uptime.strftime("%d-%m-%Y %H:%M:%S")}
🧑‍💻 Pengguna: {sender.first_name}
🔐 Status: ✅ Authorized

📡 Panel manajemen lengkap:
➤ SSH / OVPN
➤ XRAY Vmess / Vless / Trojan
➤ VPS Monitoring & Info Tools

📲 Gunakan tombol di bawah untuk mengakses menu utama atau menghubungi owner.

📌 Jangan bagikan akun ke orang asing!
```"""

    # Kirim teks dengan tombol di bawah kolom chat
    await event.respond(
        start_text,
        buttons=[
            [Button.inline("📁 Menu Utama", data="menu")],
            [Button.url("👤 Owner", "https://t.me/username_owner")]  # Ganti ke username owner
        ],
        parse_mode="md",
        resize=True
    )