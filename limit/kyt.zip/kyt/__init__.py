from telethon import *
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math, logging
from telethon import Button
from menu import *  # ⬅️ penting: import menu.py biar fungsi callback tetap aktif

# Logging & Uptime
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# Load variabel dari file eksternal
exec(open("kyt/var.txt", "r").read())

# Start bot
bot = TelegramClient("ddsdswl", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# Inisialisasi database
try:
    open("kyt/database.db")
except:
    x = sqlite3.connect("kyt/database.db")
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)", (ADMIN,))
    x.commit()

def get_db():
    x = sqlite3.connect("kyt/database.db")
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    db = get_db()
    x = db.execute("SELECT user_id FROM admin").fetchall()
    a = [v[0] for v in x]
    return "true" if id in a else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])

@bot.on(events.NewMessage(pattern="/start"))
async def start_cmd(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "false":
        await event.reply("🚫 Akses Ditolak, lu bukan mets 😎")
        return

    await event.reply(
        "🔰 Selamat Datang di *𝗞𝗘𝗠𝗘𝗧 𝗝𝗦 𝗦𝗧𝗢𝗥𝗘* 🔰\n\n"
        "📡 Layanan *VPN Premium* & *Aman* siap digunakan!\n"
        "🔒 Privasi terjaga, akses stabil, dan konfigurasi lengkap hanya di sini.\n\n"
        "📁 Klik tombol di bawah untuk membuka Menu Utama.\n"
        "👤 Butuh bantuan langsung? Klik tombol Owner.\n\n"
        "🔥 𝗕𝗼𝘁 𝗗𝗶𝗸𝗲𝗻𝗱𝗮𝗹𝗶𝗸𝗮𝗻 𝗼𝗹𝗲𝗵: @kemetstore 🔥",
        buttons=[
            [Button.inline("📁 Menu Utama", data="menu")],
            [Button.url("👤 Owner", "https://t.me/username_owner")]
        ],
        link_preview=False
    )