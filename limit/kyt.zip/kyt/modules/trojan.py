@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as conv:
			await event.respond('**Username:**')
			username = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			username = (await username).raw_text

		async with bot.conversation(chat) as conv:
			await event.respond("**Quota (GB):**")
			quota = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = (await quota).raw_text

		async with bot.conversation(chat) as conv:
			await event.respond("**Limit-IP:**")
			limit_ip = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text

		async with bot.conversation(chat) as conv:
			await event.respond("**Expired (in days):**")
			expired = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			expired = (await expired).raw_text

		# Animasi proses
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")

		# Eksekusi script
		cmd = f'printf "%s\n" "{username}" "{quota}" "{limit_ip}" "{expired}" | bot-add-tro'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except Exception as e:
			await event.respond(f"❌ Gagal membuat akun `{username}`.")
			print(e)
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(expired))
			b = [x.group() for x in re.finditer("trojan://(.*)", a)]
			domain = re.search("@(.*?):", b[0]).group(1)
			uuid = re.search("trojan://(.*?)@", b[0]).group(1)

			msg = f"""
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**🐾🕊️ Xray/Trojan Account 🕊️🐾**
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Remarks     :** `{username}`
**» Host Server :** `{domain}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `{quota} GB`
**» Port DNS    :** `443, 53`
**» Port TLS    :** `222-1000`
**» User ID     :** `{uuid}`
**» Pub Key     :** `{PUB}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link WS     :** 
`{b[0].replace(" ","")}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link GRPC   :** 
`{b[1].replace(" ","")}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» OpenClash Format :**
`https://{domain}:81/trojan-{username}.txt`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**Expired Until:** `{later}`
"""
			await event.respond(msg, buttons=[
				[Button.inline("🔙 Kembali ke Menu", data=b"menu-utama")]
			])

	# Validasi user & panggil fungsi
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)
#LOCK trojan
@bot.on(events.CallbackQuery(data=b'lock-trojan'))
async def lock_trojan(event):
	async def lock_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK trojan
@bot.on(events.CallbackQuery(data=b'unlock-trojan'))
async def unlock_trojan(event):
	async def unlock_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Trojan**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as conv:
			await event.respond("**Durasi Trial (menit):**")
			durasi = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			durasi = (await durasi).raw_text

		# Animasi Proses
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Create Trial Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up a Trial Account`")

		# Eksekusi script
		cmd = f'printf "%s\n" "{durasi}" | bot-trial-tro'
		try:
			output = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except Exception as e:
			await event.respond("❌ Gagal membuat akun trial.")
			print(e)
			return

		try:
			b = [x.group() for x in re.finditer("trojan://(.*)", output)]
			remarks = re.search("#(.*)", b[0]).group(1)
			domain = re.search("@(.*?):", b[0]).group(1)
			uuid = re.search("trojan://(.*?)@", b[0]).group(1)
		except Exception as parse_error:
			await event.respond("❌ Gagal parsing hasil output.")
			print(parse_error)
			return

		# Kirim hasil
		msg = f"""
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**🧪 Xray/Trojan Trial Account**
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Remarks     :** `{remarks}`
**» Host Server :** `{domain}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `Unlimited`
**» Port DNS    :** `443, 53`
**» Port TLS    :** `222-1000`
**» Path Trojan :** `(/multi path)/trojan-ws`
**» User ID     :** `{uuid}`
**» Pub Key     :** {PUB}
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link WS     :** 
`{b[0].replace(" ","")}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link GRPC   :** 
`{b[1].replace(" ","")}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Expired in:** `{durasi} Minutes`
"""
		await event.respond(msg, buttons=[
			[Button.inline("🔙 Kembali ke Menu", data=b"menu-utama")]
		])

	# Validasi user & eksekusi
	chat = event.chat_id
	sender = await event.get_sender()
	if valid(str(sender.id)) == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-tro'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User `{user}` Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" ⏳𝙏𝙍𝙄𝘼𝙇 𝙏𝙍𝙊𝙅𝘼𝙉 ","trial-trojan"),
Button.inline(" 🛒𝘾𝙍𝙀𝘼𝙏𝙀 𝙏𝙍𝙊𝙅𝘼𝙉 ","create-trojan")],
[Button.inline(" 🖥️𝘾𝙃𝙀𝘾𝙆 𝙏𝙍𝙊𝙅𝘼𝙉 ","cek-trojan"),
Button.inline(" ❌𝘿𝙀𝙇𝙀𝙏𝙀 𝙏𝙍𝙊𝙅𝘼𝙉 ","delete-trojan")],
[Button.inline(" 🌀𝙇𝙊𝘾𝙆 𝙏𝙍𝙊𝙅𝘼𝙉 ","lock-trojam"),
Button.inline(" 🌐𝙐𝙉𝙇𝙊𝘾𝙆 𝙏𝙍𝙊𝙅𝘼𝙉 ","unlock-trojan")],
[Button.inline("🔙 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""```
ooo        ooooo               .            
`88.       .888'             .o8            
 888b     d'888   .ooooo.  .o888oo  .oooo.o 
 8 Y88. .P  888  d88' `88b   888   d88(  "8 
 8  `888'   888  888ooo888   888   `"Y88b.  
 8    Y     888  888    .o   888 . o.  )88b 
o8o        o888o `Y8bod8P'   "888" 8""888P'    
╒════════════════════════
│  ⠭⠿☬ TROJAN MANAGER ☬⠿⠭
╞════════════════════════
│♃ » Service: TROJAN
│♃ » Hostname/IP: {DOMAIN}
│♃ » ISP: {z["isp"]}
│♃ » Country: {z["country"]}
╘════════════════════════❐
```"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
