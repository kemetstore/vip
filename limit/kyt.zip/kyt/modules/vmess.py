from kyt import *
import subprocess, re, json, base64, datetime as DT
from telethon import events, Button
import time

@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        # Step 1: Input Username
        async with bot.conversation(chat) as conv:
            await event.respond("📝 **Masukkan Username:**")
            user = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (user.raw_text or "").strip()

        # Step 2: Pilih Kuota
        await event.respond("📦 **Pilih Kuota:**", buttons=[
            [Button.inline("5 GB", b"5"), Button.inline("10 GB", b"10")],
            [Button.inline("15 GB", b"15"), Button.inline("Unlimited", b"unli")]
        ])
        pw = await bot.wait_for(events.CallbackQuery(from_users=sender.id))
        await pw.answer()
        pw = pw.data.decode("ascii")

        # Step 3: Pilih Limit IP
        await event.respond("🌐 **Pilih Limit IP:**", buttons=[
            [Button.inline("1 IP", b"1"), Button.inline("2 IP", b"2")],
            [Button.inline("3 IP", b"3"), Button.inline("Unlimited", b"unli")]
        ])
        pw1 = await bot.wait_for(events.CallbackQuery(from_users=sender.id))
        await pw1.answer()
        pw1 = pw1.data.decode("ascii")

        # Step 4: Pilih Masa Aktif
        await event.respond("⏳ **Pilih Masa Aktif:**", buttons=[
            [Button.inline("1 Hari", b"1"), Button.inline("3 Hari", b"3")],
            [Button.inline("7 Hari", b"7"), Button.inline("30 Hari", b"30")]
        ])
        exp = await bot.wait_for(events.CallbackQuery(from_users=sender.id))
        await exp.answer()
        exp = exp.data.decode("ascii")

        # Animasi Proses
        await event.edit("`Processing Create Premium Account`")
        for percent, bar in [
            ("0%", "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            ("4%", "█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            ("8%", "██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            ("20%", "█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            ("36%", "█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            ("52%", "█████████████▒▒▒▒▒▒▒▒▒▒▒"),
            ("84%", "█████████████████████▒▒▒▒"),
            ("100%", "█████████████████████████")
        ]:
            await event.edit(f"`Processing... {percent}\n{bar} `")
            time.sleep(0.4)
        await event.edit("`Wait.. Setting up an Account`")

        # Eksekusi backend
        cmd = f'printf "%s\\n" "{user}" "{pw}" "{pw1}" "{exp}" | bot-add-vme'
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            return await event.respond("❌ **User sudah ada atau backend error!**")

        b = [x.group() for x in re.finditer("vmess://(.*)", output)]
        z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
        z1 = json.loads(base64.b64decode(b[1].replace("vmess://", "")).decode("ascii"))
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        msg = f"""
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**🌐 Xray/Vmess Account 🌐**
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{pw} GB`
**» Limit IP     :** `{pw1}`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» Path TLS     :** `/multi path/vmess`
**» Path NTLS    :** `/multi path/vmess`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link TLS     :** 
``{b[0].strip()}``
**» Link NTLS    :** 
``{b[1].strip()}``
**» OpenClash :** https://{DOMAIN}:81/vmess-{user}.txt
**» Expired Until:** `{later}`
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃
*_PEMBELIAN BERHASIL_*
➭ PRODUK : VMESS
➭ REGION : {city}
➭ USER   : {user}
➭ DEVICE : {pw1} IP
➭ AKTIF  : {exp} HARI
➭ TGL EXP : {later}
⚃┅┅┅┅┅┅┅┅┅┅┅┅⚃
  *⦋KEMET JS STORE VPN⦌*
"""
        await event.respond(msg, buttons=[
            [Button.inline("⬅️ Kembali ke Menu", b'menu')]
        ])

    # Cek izin & lanjut
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Minutes:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-trial-vme'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User Trial Successfully Created**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**🌐 Xray/Vmess Account 🌐**
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `Unlimited`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link TLS     :** 
`{b[0].strip("'").replace(" ","")}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Link NTLS    :** 
`{b[1].strip("'").replace(" ","")}`
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{z["ps"]}.txt
**⬕▭▭▭▭▭▭▭▭▭▭▭▭⬔**
**» Expired Until:** `{later}`
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#LOCK VMESS
@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
	async def lock_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-lock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Locked**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK VMESS
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
	async def unlock_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | bot-unlock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{exp}` **Successfully Unlock**")
		else:
			msg = f"""**Successfully Locked**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-vme'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully Deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline("⏳𝙏𝙧𝙞𝙖𝙡 𝙑𝙢𝙚𝙨𝙨","trial-vmess"),
Button.inline("🛒𝘾𝙧𝙚𝙖𝙩𝙚 𝙑𝙢𝙚𝙨𝙨","create-vmess")],
[Button.inline("🖥️𝘾𝙝𝙚𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","cek-vmess"),
Button.inline("❌𝘿𝙚𝙡𝙚𝙩𝙚 𝙑𝙢𝙚𝙨𝙨","delete-vmess")],
[Button.inline("🌀𝙇𝙤𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","lock-vmess"),
Button.inline("🌐𝙐𝙣𝙡𝙤𝙘𝙠 𝙑𝙢𝙚𝙨𝙨","unlock-vmess")],
[Button.inline("🔙 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
❐════════════════════════❐
    ⠭⠿☬ VMESS MANAGER ☬⠿⠭
❐════════════════════════❐
♃ » Service: VMESS
♃ » Hostname/IP: `{DOMAIN}`
♃ » ISP: `{z["isp"]}`
♃ » Country: `{z["country"]}`
❐════════════════════════❐
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)