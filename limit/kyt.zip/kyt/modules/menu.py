from kyt import *

# --- REPLY KEYBOARD /start ---
@bot.on(events.NewMessage(pattern='/start'))
async def welcome(event):
    await event.respond(
        "👋 *Selamat datang di KEMET JS STORE VPN!*\n\n"
        "Silakan pilih menu di bawah ini untuk lanjut bro 👇",
        parse_mode="markdown",
        buttons=Button.reply_keyboard(
            [
                ["🚀 MENU", "👤 CONTACT OWNER"]
            ],
            resize=True,
            single_use=False
        )
    )

# --- HANDLE TOMBOL REPLY KEYBOARD ---
@bot.on(events.NewMessage(pattern=r"^(🚀 MENU|👤 CONTACT OWNER)$"))
async def handle_reply_buttons(event):
    if event.raw_text == "🚀 MENU":
        await menu(event)
    elif event.raw_text == "👤 CONTACT OWNER":
        await event.respond(
            "📞 Untuk bantuan, hubungi owner:\n👉 [@yourusername](https://t.me/yourusername)",
            parse_mode="markdown"
        )

# --- .mets ATAU /menu/start ATAU CALLBACK INLINE MENU ---
@bot.on(events.NewMessage(pattern=r"(?:.mets|/menu/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🌺 Ssh Ovpn Manager", b"ssh")],
        [Button.inline("🪷 Vmess Manager", b"vmess"), Button.inline("🌹 Vless Manager", b"vless")],
        [Button.inline("🌷 Trojan Manager", b"trojan"), Button.inline("🪻 Shadowsocks Manager", b"shadowsocks")],
        [Button.inline("🖥️ Cek VPS Info", b"info"), Button.inline("🛠️ Setting Lain", b"setting")],
        [Button.inline("♲ Back Menu", b"start")]
    ]

    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        try:
            await event.answer("⛔ Akses Ditolak, lu bukan mets!", alert=True)
        except:
            await event.reply("⛔ Akses Ditolak, lu bukan mets!")
        return

    # --- NGAMBIL DATA SERVER ---
    ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode().strip()
    vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode().strip()
    vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode().strip()
    trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode().strip()
    namaos = subprocess.check_output("cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2", shell=True).decode().strip().replace('"','')
    ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode().strip()

    file_path = "/root/Assets/kemetbot.jpg"
    msg = f"""```
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝙆𝙀𝙈𝙀𝙏 𝙅𝙎 𝙎𝙏𝙊𝙍𝙀 𝙑𝙋𝙉 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⼳» CREATOR : MUHAMAD ILMI
⼳» OS      : {namaos}
⼳» CITY    : {city}
⼳» DOMAIN  : {DOMAIN}
⼳» IP VPS  : {ipsaya}

⼳» Total Account Created:
⼳» SSH OVPN   : {ssh} account
⼳» XRAY VMESS : {vms} account
⼳» XRAY VLESS : {vls} account
⼳» XRAY TROJAN: {trj} account
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
LEBIH BAIK GAGAL DENGAN IDE ORIGINAL, 
DARIPADA SUKSES DENGAN CARA IMITASI
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
𝗩𝟱𝗕𝗼𝘁 -𝗠𝗲𝘁𝗦𝗦𝘁𝗼𝗿𝗲 
```"""

    try:
        await event.respond(msg, file=file_path, buttons=inline)
    except:
        await event.reply(msg, file=file_path, buttons=inline)