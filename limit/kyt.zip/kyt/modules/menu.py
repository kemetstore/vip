from kyt import *
import subprocess
from telethon import events, Button
import datetime as DT

uptime = DT.datetime.now()

def count_pattern(pattern):
    try:
        result = subprocess.run(
            ["grep", "-c", "-E", pattern, "/etc/xray/config.json"],
            capture_output=True,
            text=True,
            check=True
        )
        count = int(result.stdout.strip())
        return str(count // 2)
    except subprocess.CalledProcessError:
        return "0"

@bot.on(events.NewMessage(pattern=r"(?:.mets|/menu/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🌺𝙎𝙨𝙝 𝙊𝙫𝙥𝙣 𝙈𝙖𝙣𝙖𝙜𝙚𝙧🌺","ssh")],
        [Button.inline("🪷𝙑𝙢𝙚𝙨𝙨 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","vmess"),
         Button.inline("🌹𝙑𝙡𝙚𝙨𝙨 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","vless")],
        [Button.inline("🌷𝙏𝙧𝙤𝙟𝙖𝙣 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","trojan"),
         Button.inline("🪻𝙎𝙝𝙙𝙬𝙨𝙠 𝙈𝙖𝙣𝙖𝙜𝙚𝙧","shadowsocks")],
        [Button.inline("🖥️𝘾𝙝𝙚𝙘𝙠 𝙑𝙥𝙨 𝙄𝙣𝙛𝙤","info"),
         Button.inline("🛠️𝙊𝙩𝙝𝙚𝙧 𝙎𝙚𝙩𝙩𝙞𝙣𝙜","setting")],
        [Button.inline("♲ Back Menu ♲", data="/start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak, lu bukan mets", alert=True)
        except:
            await event.reply("Akses Ditolak, lu bukan mets")
        return

    # Ambil data sistem
    ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode().strip()
    vms = count_pattern("### ")
    vls = count_pattern("#& ")
    trj = count_pattern("#! ")
    sss = count_pattern("#ss# ")
    namaos = subprocess.check_output('cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d= -f2', shell=True).decode().strip().replace('"','')
    ipsaya = subprocess.check_output('curl -s ipv4.icanhazip.com', shell=True).decode().strip()
    city = subprocess.check_output('cat /etc/xray/city', shell=True).decode().strip()

    file_path = "/root/Assets/kemetbot.jpg"
    msg = f"""```

▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝙆𝙀𝙈𝙀𝙏 𝙅𝙎 𝙎𝙏𝙊𝙍𝙀 𝙑𝙋𝙉 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⼳» 𝗖𝗥𝗘𝗔𝗧𝗢𝗥 : MUHAMAD ILMI
⼳» 𝗢𝗦     : {namaos}
⼳» 𝗖𝗜𝗧𝗬 : {city}
⼳» 𝗗𝗢𝗠𝗔𝗜𝗡 : {DOMAIN}
⼳» 𝗜𝗣 𝗩𝗣𝗦 : {ipsaya}

⼳» 𝚃𝚘𝚝𝚊𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 𝙲𝚛𝚎𝚊𝚝𝚎𝚍:
⼳» 𝗦𝗦𝗛 𝗢𝗩𝗣𝗡    : {ssh} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗠𝗘𝗦𝗦  : {vms} account
⼳» 𝗫𝗥𝗔𝗬 𝗩𝗟𝗘𝗦𝗦  : {vls} account
⼳» 𝗫𝗥𝗔𝗬 𝗧𝗥𝗢𝗝𝗔𝗡 : {trj} account
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
ʟᴇʙɪʜ ʙᴀɪᴋ ɢᴀɢᴀʟ ᴅᴇɴɢᴀɴ ɪᴅᴇ ᴏʀɪɢɪɴᴀʟ, 
ᴅᴀʀɪᴘᴀᴅᴀ ꜱᴜᴋꜱᴇꜱ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ɪᴍɪᴛᴀꜱɪ
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 𝗩𝟱𝗕𝗼𝘁 -𝗠𝗲𝘁𝗦𝗦𝘁𝗼𝗿𝗲 
```"""
    try:
        await event.edit(msg, file=file_path, buttons=inline)
    except:
        await event.reply(msg, file=file_path, buttons=inline)

# 🔁 Handler untuk tombol Back Menu (data='start')
@bot.on(events.CallbackQuery(data=b'/start'))
async def back_to_start(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) == "false":
        await event.answer("Akses Ditolak, lu bukan mets 😎", alert=True)
        return

    file_url = "https://telegra.ph/file/1234567890abcdef.jpg"  # Ganti dengan URL banner kamu

    start_text = f"""```
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⠭⠶⠿🌺 𝗞𝗘𝗠𝗘𝗧 𝗝𝗦 𝗦𝗧𝗢𝗥𝗘 𝗩𝗣𝗡 𝗕𝗢𝗧 🌺⠿⠶⠭
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
📆 Aktif Sejak: {uptime.strftime("%d-%m-%Y %H:%M:%S")}
🧑‍💻 Pengguna: {sender.first_name}
🔐 Status:  Authorized

📡 Panel manajemen lengkap:
➤ SSH / OVPN
➤ XRAY Vmess / Vless / Trojan
➤ VPS Monitoring & Info Tools

📲 Gunakan tombol di bawah untuk mengakses menu utama atau menghubungi owner.

📌 Jangan bagikan akun ke orang asing!
```"""

    await event.edit_message(
        file=file_url,
        text=start_text,
        buttons=[
            [Button.inline("📁 Menu Utama", data="menu")],
            [Button.url("👤 Owner", "https://t.me/username_owner")]
        ],
        parse_mode="md"
    )